#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h" // for MAGIC_STRING

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if ((strstr(argv[2], ".bmp") != NULL))
    {
        decInfo->stego_image_fname = argv[2];
    }
    else
    {
        return e_failure;
    }

    if (argv[3] != NULL)
    {
        decInfo->secret_fname = argv[3];
    }
    else
    {
        decInfo->secret_fname = "output.txt";
    }

    return e_success;
}

Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);
        return e_failure;
    }

    decInfo->fptr_secret = fopen(decInfo->secret_fname, "w");
    if (decInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->secret_fname);
        return e_failure;
    }

    return e_success;
}

Status skip_bmp_header(FILE *fptr_image)
{
    fseek(fptr_image, 54, SEEK_SET);
    return e_success;
}

Status decode_byte_from_lsb(char *image_buffer, char *data)
{
    char ch = 0;
    for (int i = 0; i < 8; i++)
    {
        ch |= (image_buffer[i] & 1) << i;
    }
    *data = ch;
    return e_success;
}

Status decode_size_from_lsb(int *size, DecodeInfo *decInfo)
{
    char image_buffer[32];
    *size = 0;
    fread(image_buffer, 32, 1, decInfo->fptr_stego_image);
    for (int i = 0; i < 32; i++)
    {
        *size |= (image_buffer[i] & 1) << i;
    }
    return e_success;
}

Status decode_data_from_image(char *data, int size, DecodeInfo *decInfo)
{
    for (int i = 0; i < size; i++)
    {
        char image_buffer[8];
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image);
        decode_byte_from_lsb(image_buffer, &data[i]);
    }
    return e_success;
}

Status decode_magic_string(char *magic_str, DecodeInfo *decInfo)
{
    char buffer[strlen(MAGIC_STRING)];
    decode_data_from_image(buffer, strlen(MAGIC_STRING), decInfo);
    if (strncmp(buffer, MAGIC_STRING, strlen(MAGIC_STRING)) == 0)
        return e_success;
    else
        return e_failure;
}

Status decode_secret_file_extn_size(int *size, DecodeInfo *decInfo)
{
    return decode_size_from_lsb(size, decInfo);
}

Status decode_secret_file_extn(char *file_extn, int size, DecodeInfo *decInfo)
{
    decode_data_from_image(file_extn, size, decInfo);
    file_extn[size] = '\0';
    return e_success;
}

Status decode_secret_file_size(long *size, DecodeInfo *decInfo)
{
    int temp;
    decode_size_from_lsb(&temp, decInfo);
    *size = temp;
    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char *data = malloc(decInfo->size_secret_file + 1);
    decode_data_from_image(data, decInfo->size_secret_file, decInfo);
    fwrite(data, decInfo->size_secret_file, 1, decInfo->fptr_secret);
    free(data);
    return e_success;
}

Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo) == e_success)
    {
        printf("\nINFO : Open decode files success\n");
        skip_bmp_header(decInfo->fptr_stego_image);

        if (decode_magic_string(MAGIC_STRING, decInfo) == e_success)
        {
            printf("\nINFO : Magic string matched\n");

            int extn_size;
            decode_secret_file_extn_size(&extn_size, decInfo);

            decode_secret_file_extn(decInfo->extn_secret_file, extn_size, decInfo);

            decode_secret_file_size(&decInfo->size_secret_file, decInfo);

            decode_secret_file_data(decInfo);

            printf("\nINFO : Decoding completed successfully\n");
            return e_success;
        }
        else
        {
            printf("\nERROR : Magic string mismatch\n");
            return e_failure;
        }
    }
    else
    {
        return e_failure;
    }
}
