#ifndef DECODE_H
#define DECODE_H
#define MAX_FILE_SUFFIX 4
#include "types.h"

typedef struct _DecodeInfo
{
    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

    /* Secret File Info */
    char *secret_fname;
    FILE *fptr_secret;
    char extn_secret_file[MAX_FILE_SUFFIX];
    long size_secret_file;
    char *magic_string;
} DecodeInfo;

/* Decoding function prototypes */

/* Read and validate decode args */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Open files */
Status open_decode_files(DecodeInfo *decInfo);

/* Skip BMP header */
Status skip_bmp_header(FILE *fptr_image);

/* Decode magic string */
Status decode_magic_string(char *magic_str, DecodeInfo *decInfo);

/* Decode size (int) */
Status decode_size_from_lsb(int *size, DecodeInfo *decInfo);

/* Decode data (string/binary) */
Status decode_data_from_image(char *data, int size, DecodeInfo *decInfo);

/* Decode secret file extension size */
Status decode_secret_file_extn_size(int *size, DecodeInfo *decInfo);

/* Decode secret file extension */
Status decode_secret_file_extn(char *file_extn, int size, DecodeInfo *decInfo);

/* Decode secret file size */
Status decode_secret_file_size(long *size, DecodeInfo *decInfo);

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo);

#endif
