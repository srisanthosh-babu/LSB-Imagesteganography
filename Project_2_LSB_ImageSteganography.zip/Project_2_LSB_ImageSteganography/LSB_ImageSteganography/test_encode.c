
#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc,char*argv[])
{
	
	if(argc<3){
		printf("Usage: \n For Encoding:./a.out -e beautiful.bmp secret.txt [stegano.bmp]\nFor Decoding: ./a.out -d stegano.bmp [data.txt]\n");
		return 0;
	}
		
	int res=check_operation_type(argv);
	EncodeInfo E1;
	DecodeInfo D1;
	if(res==e_encode){
		printf("\nSelected Encoding\n");
		if(read_and_validate_encode_args(argv,&E1)== e_success){
			printf("\nINFO : Read and Validate encode args is success\n");
			if(do_encoding(&E1) == e_success) {
				printf("\nINFO : Encoding is success\n");
			}
			else{
				printf("\nERROR : Encoding is failure\n");
			}
		}
		else{
			printf("\nERROR : Read and Valdate encode args is failure\n");
			return 0;
		}
	}
	else if(res==e_decode){
		printf("\nSelected Decoding\n");
		if(read_and_validate_decode_args(argv,&D1)==e_success){
			printf("\nINFO : Read and Validate decode args is success\n");
			if(do_decoding(&D1)==e_success){
				printf("\nINFO : Decoding is success\n");
			}
			else{
				printf("\nERROR : Decoding is failure\n");
				return 0;
			}		
		}
		else{
			printf("\nERROR : Read and Validate decode args is failure\n");
			return 0;
		}
	}
	else{
		printf("\nInvalid option \nUsage:\nFor Encoding:./a.out -e beautiful.bmp secret.txt [stegano.bmp]\nFor Decoding ./a.out -d stegano.bmp [data.txt]\n");
	}
	return 0;
}
OperationType check_operation_type(char*argv[]){
	if(strcmp(argv[1],"-e")==0){
		return e_encode;
	}
	else if(strcmp(argv[1],"-d")==0){
		return e_decode;
	}
}
    /*EncodeInfo encInfo;
    uint img_size;

    // Fill with sample filenames
    encInfo.src_image_fname = "beautiful.bmp";
    encInfo.secret_fname = "secret.txt";
    encInfo.stego_image_fname = "stego_img.bmp";

    // Test open_files
    if (open_files(&encInfo) == e_failure)
    {
    	printf("ERROR: %s function failed\n", "open_files" );
    	return 1;
    }
    else
    {
    	printf("SUCCESS: %s function completed\n", "open_files" );
    }

    // Test get_image_size_for_bmp
    img_size = get_image_size_for_bmp(encInfo.fptr_src_image);
    printf("INFO: Image size = %u\n", img_size);

    return 0;
}*/
